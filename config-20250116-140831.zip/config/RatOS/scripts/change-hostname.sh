#!/bin/bash
sudo /home/pi/printer_data/config/RatOS/scripts/change-hostname-as-root.sh $1
