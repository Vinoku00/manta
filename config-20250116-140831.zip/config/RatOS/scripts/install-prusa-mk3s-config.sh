#!/bin/bash

tail -n +2 /home/pi/printer_data/config/RatOS/templates/prusa-mk3s-printer.template.cfg > /home/pi/printer_data/config/printer.cfg
