#!/bin/bash

tail -n +2 /home/pi/printer_data/config/RatOS/templates/v-core-pro-printer.template.cfg > /home/pi/printer_data/config/printer.cfg
